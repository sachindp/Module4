/********************************************************
 * Author 		: Sachin 
 * File Name 	: required.sql 
 * Folder 		: Web Content
 * Date 		: Dec 04, 2017
 * Description	: SQL Query to create database.
 ********************************************************/

create table users	(name varchar2(40),
					user_name varchar2(40) primary key,
					password varchar2(15),
					mobile_number varchar2(12));