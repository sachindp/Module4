package com.capgemini.airspace.exception;

/***********************************************************
 * Author 		: Sachin
 * Class Name 	: DonorTransactionException 
 * File Type	: Exception File.
 * Package 		: com.capgemini.airspace.exception
 * Date 		: Dec 04, 2017
 * Description	: This file handles all exception generated
 * 				  during the execution.
 **********************************************************/

@SuppressWarnings("serial")
public class AirSpaceException extends Exception{
	public AirSpaceException(String message)
	{
		super(message);
	}
}
