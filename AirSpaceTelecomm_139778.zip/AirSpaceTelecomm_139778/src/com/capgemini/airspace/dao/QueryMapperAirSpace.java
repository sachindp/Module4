package com.capgemini.airspace.dao;

/********************************************************
 * Author 		: Sachin 
 * File Name 	: QueryMapperAirSpace.java
 * File Type	: Interface
 * Package 		: com.capgemini.airspace.dao
 * Date 		: Dec 04, 2017
 * Description	: Interface defining sql query for insertion of a new user.
 ********************************************************/

public interface QueryMapperAirSpace {

	public static final String INSERT_USER ="INSERT INTO users VALUES(?,?,?,?)";
	
}
