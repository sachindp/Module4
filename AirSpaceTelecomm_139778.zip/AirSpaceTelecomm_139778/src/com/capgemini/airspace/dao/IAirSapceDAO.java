/********************************************************
 * Author 		: Sachin 
 * File Name 	: IAirSpaceDAO.java
 * File Type	: Interface
 * Package 		: com.capgemini.airspace.dao
 * Date 		: Dec 04, 2017
 * Description	: Performing User details insertion
 * 				  by calling object of Bean Class.
 ********************************************************/

package com.capgemini.airspace.dao;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.AirSpaceException;

public interface IAirSapceDAO {
	public boolean insertUser(UserBean user) throws AirSpaceException;
}
