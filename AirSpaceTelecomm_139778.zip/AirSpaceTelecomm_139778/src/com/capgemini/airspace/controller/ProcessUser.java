package com.capgemini.airspace.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.AirSpaceException;
import com.capgemini.airspace.service.AirSpaceServiceImpl;
import com.capgemini.airspace.service.IAirSpaceService;

/********************************************************
 * Author 		: Sachin 
 * File Name 	: ProcesUser.java
 * Package 		: com.capgemini.airspace.controller
 * Date 		: Dec 04, 2017
 * Description	: Servlet to perform registration of user,
 * 				  pay bills, view bills.
 ********************************************************/

/**
 * Servlet implementation class ProcessUser
 */
@WebServlet({"/ProcessUser","/Home","/Register","/PayBill","/Success"})
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path=request.getServletPath();
		HttpSession session=request.getSession(true);
		String target="";
		
		if(path.equals("/Home"))
		{
			target="view/Register.jsp";
		}
		if(path.equals("/Register"))
		{
			IAirSpaceService service = new AirSpaceServiceImpl();
			UserBean user = new UserBean();
			
			user.setName(request.getParameter("name"));
			user.setUserName(request.getParameter("userName"));
			user.setMobileNo(request.getParameter("mobileNo"));
			user.setPassword(request.getParameter("password"));
			session.setAttribute("user", user);
			
			try {
				boolean isInserted = service.insertUser(user);
				if(isInserted){
					target="view/CustomerHome.jsp";
				}
			} catch (AirSpaceException e) {
				request.setAttribute("error", e.getMessage());
				target="view/Error.jsp";
			}
		}
		
		if(path.equals("/PayBill"))
		{
			target="view/PayBill.jsp";
		}
		
		if(path.equals("/Success"))
		{
			int amount = Integer.parseInt(request.getParameter("amount"));
			int balanceAmount = 750 - amount;
			request.setAttribute("balance", balanceAmount);
			request.setAttribute("Date", LocalDate.now());
			target="view/Success.jsp";
		}
		RequestDispatcher disp=request.getRequestDispatcher(target);
		disp.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
