/***********************************************************
 * Author 		: Sachin
 * Class Name 	: DonorTransactionException 
 * File Type	: Interface File.
 * Package 		: com.capgemini.airspace.service
 * Date 		: Dec 04, 2017
 * Description	: Service Interface.
 **********************************************************/

package com.capgemini.airspace.service;

import com.capgemini.airspace.dto.UserBean;
import com.capgemini.airspace.exception.AirSpaceException;

public interface IAirSpaceService {
	public boolean insertUser(UserBean user) throws AirSpaceException;
}
