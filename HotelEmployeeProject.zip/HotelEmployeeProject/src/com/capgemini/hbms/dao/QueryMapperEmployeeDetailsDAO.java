package com.capgemini.hbms.dao;

public interface QueryMapperEmployeeDetailsDAO {
	
	public static final String REGISTER_EMPLOYEE = "INSERT INTO users VALUES(user_id_sequence.nextval,?,?,?,?,?,?,?)";
	
	public static final String SHOW_EMPLOYEEID = "SELECT user_id_sequence.CURRVAL FROM DUAL";
	
	public static final String GET_EMPLOYEE_CREDENTIALS = "SELECT user_id,password FROM users";
}