package com.capgemini.hbms.dao;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.exception.EmployeeException;

public interface IBookingDetailsDao {
boolean bookHotel(BookingDetailsBean bookingDetailsBean) throws EmployeeException;
	
	boolean bookingStatus(String bookingId) throws EmployeeException;
}
