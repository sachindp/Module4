package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.EmployeeDetailsBean;
import com.capgemini.hbms.exception.EmployeeException;

public interface IEmployeeDetailsDao {
	int RegisterEmployee(EmployeeDetailsBean userDetails) 
			throws EmployeeException;
	
	public List<EmployeeDetailsBean> LoginCheck()
			throws EmployeeException;
}
