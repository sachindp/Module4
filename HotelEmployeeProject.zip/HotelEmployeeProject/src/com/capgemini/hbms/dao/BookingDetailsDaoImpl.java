package com.capgemini.hbms.dao;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.exception.EmployeeException;

public class BookingDetailsDaoImpl implements IBookingDetailsDao {

	@Override
	public boolean bookHotel(BookingDetailsBean bookingDetailsBean)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean bookingStatus(String bookingId) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

}
