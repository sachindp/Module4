package com.capgemini.hbms.dao;

public interface QueryMapperBookingDetailsDAO {
	
	public static final String BOOK_HOTEL = "INSERT INTO users VALUES(booking_id_sequence.nextval,?,?,?,?,?,?,?)";
}
