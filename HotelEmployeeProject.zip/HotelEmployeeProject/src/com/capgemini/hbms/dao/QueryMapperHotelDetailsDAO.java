package com.capgemini.hbms.dao;

public interface QueryMapperHotelDetailsDAO {

	public static final String SHOW_HOTELS = "SELECT hotel_id,city,hotel_name,address,"
			+ "description,avg_rate_per_night,phone_no1,phone_no2,"
			+ "rating,email,fax FROM hotel";
	
}
