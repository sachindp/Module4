package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.exception.EmployeeException;

public class HotelDetailsDaoImpl implements IHotelDetailsDao {

	@Override
	public List<HotelBean> viewHotels() throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

}
