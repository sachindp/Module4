package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.EmployeeDetailsBean;
import com.capgemini.hbms.exception.EmployeeException;
import com.capgemini.hbms.util.DBConnection;

public class EmployeeDetailsDaoImpl implements IEmployeeDetailsDao {

	@Override
	public int RegisterEmployee(EmployeeDetailsBean userDetails)
			throws EmployeeException {
		int userId = 0;
		int records = 0;
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperEmployeeDetailsDAO.REGISTER_EMPLOYEE); // Preparing query
						){
			
			//Giving values to query  statement
			preparedStatement.setString(1, userDetails.getPassword());
			preparedStatement.setString(2, userDetails.getRole());
			preparedStatement.setString(3, userDetails.getUserName());
			preparedStatement.setString(4, userDetails.getMobileNo());
			preparedStatement.setString(5, userDetails.getPhone());
			preparedStatement.setString(6, userDetails.getAddress());
			preparedStatement.setString(7, userDetails.getEmail());

			
			records = preparedStatement.executeUpdate(); //Executing the query
			
			if(records>0){	 //Checking for the record retrieval
				;
			}
			else
			{
				throw new EmployeeException();
			}
			
			PreparedStatement preparePatientID = 
					connPatient.prepareStatement(QueryMapperEmployeeDetailsDAO.SHOW_EMPLOYEEID); //Preparing query
			
			ResultSet userIDrecord = preparePatientID.executeQuery(); //Execute query
			
			if(userIDrecord.next()){
				userId = userIDrecord.getInt(1); //Patient ID Retrieved
			}
		} catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage()); //Throws error
		}
		
	return userId;
	}

	@Override
	public List<EmployeeDetailsBean> LoginCheck() throws EmployeeException {
		EmployeeDetailsBean userDetailsBean;
		List<EmployeeDetailsBean> userCredentialsList = new ArrayList<EmployeeDetailsBean>();
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperEmployeeDetailsDAO.GET_EMPLOYEE_CREDENTIALS); // Preparing query
						){
			
			
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				String userId=rs.getString(1);
				String pass=rs.getString(2);
				
				userDetailsBean = new EmployeeDetailsBean(userId,pass);
				userCredentialsList.add(userDetailsBean);
			}
			
		} catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage()); //Throws error
		}
		return userCredentialsList;
	}

}
