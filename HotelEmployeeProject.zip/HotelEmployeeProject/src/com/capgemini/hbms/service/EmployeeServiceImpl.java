package com.capgemini.hbms.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.EmployeeDetailsBean;
import com.capgemini.hbms.dao.EmployeeDetailsDaoImpl;
import com.capgemini.hbms.dao.IEmployeeDetailsDao;
import com.capgemini.hbms.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDetailsDao employeeDetailsDao = new EmployeeDetailsDaoImpl() {
		
		@Override
		public int RegisterEmployee(EmployeeDetailsBean userDetails)
				throws EmployeeException {
			return employeeDetailsDao.RegisterEmployee(userDetails);
		}
		
		@Override
		public List<EmployeeDetailsBean> LoginCheck() throws EmployeeException {
			// TODO Auto-generated method stub
			return null;
		}
	};
	
	@Override
	public int RegisterUser(EmployeeDetailsBean userDetails)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean LoginCheck(EmployeeDetailsBean employeeDetails,String role)
			throws EmployeeException {
		boolean validEmployee = false;
		List<EmployeeDetailsBean> employeeCredentialsLists = new ArrayList<EmployeeDetailsBean>();
		
		for(EmployeeDetailsBean employeeCredentialsList : employeeCredentialsLists){
			if(employeeCredentialsList.getUserName().equals(employeeDetails.getEmployeeId())&&employeeCredentialsList.getPassword().equals(employeeDetails) && employeeCredentialsList.getRole().equals(role)){
				validEmployee = true;
			}
		}
		return validEmployee;
	}

	@Override
	public List<EmployeeDetailsBean> viewHotels() throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean bookHotel(BookingDetailsBean bookingDetailsBean)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean bookingStatus(String bookingId) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

}
