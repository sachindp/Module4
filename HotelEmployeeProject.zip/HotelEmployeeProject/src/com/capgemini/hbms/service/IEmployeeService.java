package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.EmployeeDetailsBean;
import com.capgemini.hbms.exception.EmployeeException;

public interface IEmployeeService {
int RegisterUser(EmployeeDetailsBean userDetails) throws EmployeeException;
	
	boolean LoginCheck(EmployeeDetailsBean userDetails,String role) throws EmployeeException;
	
	List<EmployeeDetailsBean> viewHotels() throws EmployeeException;
	
	boolean bookHotel(BookingDetailsBean bookingDetailsBean) throws EmployeeException;
	
	boolean bookingStatus(String bookingId) throws EmployeeException;
}
