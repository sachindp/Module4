package com.capgemini.hbms.ui;

public class Main {
	private String employeeId;
	private String password;
	private String role;
	private String employeeName;
	private String mobileNo;
	private String phone;
	private String address;
	private String email;
	public static void main(String[] args) {
		
	}
}
