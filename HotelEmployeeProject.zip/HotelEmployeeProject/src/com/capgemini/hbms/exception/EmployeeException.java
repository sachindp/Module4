package com.capgemini.hbms.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2183188106941595043L;
	
	public EmployeeException(){
		super();
	}
	public EmployeeException(String message){
		super(message);
	}

}
