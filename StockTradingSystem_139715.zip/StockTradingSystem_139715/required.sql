CREATE SEQUENCE stock_seq start with 101;

CREATE TABLE stock_master(stock VARCHAR2(20), quote NUMBER(7,2));

CREATE TABLE order_master(order_id NUMBER PRIMARY KEY,stock VARCHAR2(20),
quote NUMBER(7,2),order_amount NUMBER(9,2),
Commission NUMBER(7,2));

INSERT INTO stock_master values('Reliance Industries', 894.95);
INSERT INTO stock_master values('TATA Steel', 410.65);
INSERT INTO stock_master values('LNT', 1344.95);