package com.cg.exception;


/******************************StockTrading********************************/
/**************************************************************************
 * Author 		: SHIVAM SINGH 
 * Class Name 	: ShareException 
 * Package 		: com.cg.exception
 * Date 		: December 20, 2017
 **************************************************************************/


public class ShareException extends Exception 
{

	private static final long serialVersionUID = 2429005644596060387L;

	public ShareException() 
	{
		super();
		
	}

	public ShareException(String arg0) 
	{
		super(arg0);

	}
	
	

}
