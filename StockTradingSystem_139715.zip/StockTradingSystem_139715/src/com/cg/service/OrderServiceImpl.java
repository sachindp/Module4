package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.OrderBean;
import com.cg.dao.IOrderDao;
import com.cg.exception.ShareException;

/******************************StockTrading********************************/
/**************************************************************************
 * Author 		: SHIVAM SINGH 
 * Class Name 	: OrderBean 
 * Package 		: com.cg.bean
 * Date 		: December 20, 2017
 **************************************************************************/

@Service
public class OrderServiceImpl implements IOrderService
{

	@Autowired
	private IOrderDao orderDao;
	
	@Override
	public int addOrder(OrderBean oBean) throws ShareException 
	{
		
		return orderDao.addOrder(oBean);
	}

}
