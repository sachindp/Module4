package com.cg.service;

import com.cg.bean.OrderBean;
import com.cg.exception.ShareException;

public interface IOrderService 
{
	public int addOrder(OrderBean oBean) throws ShareException;
}
